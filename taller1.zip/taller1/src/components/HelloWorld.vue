<template>
 <v-ons-page>

    <v-ons-toolbar color="#0b609f">
      <div class="center">taller 1</div>
      <div class="right">
        <v-ons-toolbar-button icon="ion-navicon, material: md-menu"></v-ons-toolbar-button>
      </div>
    </v-ons-toolbar>

  <v-ons-list>
    <v-ons-list-header>Nombre</v-ons-list-header>
      <v-ons-list-item>
        <div class="center">
          <v-ons-input placeholder="introduzca su nombre" float
            v-model="form.nombre"
          ></v-ons-input>
       
        </div>
      </v-ons-list-item>  
  </v-ons-list>

    <v-ons-list>
      <v-ons-list-header>Genero</v-ons-list-header>
      
      <v-ons-list-item>
       <div class="center">

         <v-ons-select style="width: 40%"
            v-model="form.genero"
          >
            <option>
              Masculino
            </option>
            <option>
              Femenino
            </option>
          </v-ons-select>

        </div>
        
      </v-ons-list-item>
    </v-ons-list>
    
      <v-ons-list>
      <v-ons-list-header>Telefono</v-ons-list-header>
      
      <v-ons-list-item>
       <div class="center">
        <v-ons-input placeholder="Introduzca su telefono" 
          v-model="form.telefono" type="number"
        >      
        </v-ons-input>
        </div>        
      </v-ons-list-item>
    </v-ons-list>
    <v-ons-list>
      <v-ons-list-header>Carrera</v-ons-list-header>
      
      <v-ons-list-item>
     <label class="center" for="switch2">
         Carrera
        </label>
        <div class="center">

         <v-ons-select style="width: 50%"
            v-model="form.carrera"
          >
            <option>
              Ingeniería en sistemas
            </option>
            <option>
             Licenciatura en Comunicación Ejecutiva Bilingüe
            </option>
             <option>
             Licenciatura en Ingeniería de Sistemas y Computación
            </option>
             <option>
             Licenciatura en Ingenieria de Software
            </option>
             <option>             
            Técnico en Informática para la Gestión Empresarial
            </option>
             <option>
             Licenciatura en Informática Aplicada a la Educación
            </option>
             <option>
           Licenciatura en Ingeniería de Sistemas de Información
            </option>
             <option>           
            Licenciatura en Ingeniería Electromecánica
            </option>
             <option>
            Licenciatura en Ingeniería Industrial
            </option>
          </v-ons-select>

        </div>  
        
      </v-ons-list-item>
    </v-ons-list>
 <v-ons-list>
<v-ons-list-item>
   <v-ons-list-header>Terminos</v-ons-list-header>

  <label class="center" for="switch1">
          Acepta los terminos ({{ form.termino ? 'si' : 'no' }})
        </label>
        <div class="right">
          <v-ons-switch input-id="switch1"
            v-model="form.termino"
          >
          </v-ons-switch>
        </div>
      </v-ons-list-item>

    <v-ons-list-item>
      <div class="center">
          <v-ons-button @click="$ons.notification.alert('Hello World!')"
            :disabled="!form.termino"
          > Registrarse
          </v-ons-button>
        </div>
</v-ons-list-item>
  </v-ons-list>
</v-ons-page>
  
</template>

<script>
export default {
  data(){
   
    return {
      form:{
        nombre: '',
        genero:'',
        telefono:'',
        carrera:'',
        termino:false
      }
      
    }
    
  },
   methods: {
      onSubmit() {
        console.log(this.form);
      }
    }
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/* @import 'onsenui/css/onsenui.css';
@import 'onsenui/css/onsen-css-components.css'; */
</style>
