<template>
<div>
  <el-menu
  :default-active="activeIndex2"
  class="el-menu-demo"
  mode="horizontal"
  @select="handleSelect"
  background-color="#545c64"
  text-color="#fff"
  active-text-color="#ffd04b">
  <el-menu-item index="1">Taller 2</el-menu-item>
  
</el-menu>
   <el-form class="demo-form-inline">
     <el-form-item label="ID">
    <el-input v-model="id" type="number" placeholder="id"></el-input>
  </el-form-item>
  <el-form-item label="Nombre">
    <el-input v-model="nombre" placeholder="Nombre"></el-input>
  </el-form-item>
  
  <el-form-item label="Estado">
    <el-select v-model="estado" placeholder="Estado">
      <el-option label="Activo" value="Activo"></el-option>
      <el-option label="Inactivo" value="Inactivo"></el-option>
    </el-select>
  </el-form-item>
  <el-form-item label="Monto">
    <el-input type="number" v-model="monto" placeholder="Monto"></el-input>
  </el-form-item>
  <el-form-item>
    <el-button type="primary" @click="onSubmit">Agregar</el-button>
  </el-form-item>
</el-form>
<br>
<el-table
      :data="tablesprite"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="id"
        width="180">
      </el-table-column>
      <el-table-column
        prop="nombre"
        label="Nombre"
        width="180">
      </el-table-column>
      <el-table-column
        prop="estado"
        label="Estado">
      </el-table-column>
        <el-table-column
        prop="monto"
        label="Monto">
      </el-table-column>
    </el-table>
</div>
 
</template>


<script>
  export default {
    data() {
      return {
        
        id:'',
        nombre:'',

        estado:'',
        monto:'',
        tabla:[],
         tablesprite:JSON.parse(localStorage.getItem("tabla")),
      
        data:''
      }
    },
    methods: {
      onSubmit() {
          this.tabla.push({
        id: this.id,
        nombre: this.nombre,
        monto:this.monto,
        estado:this.estado
      })
        if(this.data= JSON.parse(localStorage.getItem("tabla"))==null){
            localStorage.setItem("tabla", JSON.stringify(this.tabla))
        }
        else{
          this.data=this.tabla;
          this.tabla.push( JSON.parse(localStorage.getItem("tabla")))
          localStorage.removeItem("tabla");
         localStorage.setItem("tabla", JSON.stringify(this.tabla))
         
this.data= JSON.parse(localStorage.getItem("tabla"))
        }
        
         
        console.log(this.data);
      }
    }, 
  }
</script>