<template>
  <div>
    <nav class="navbar navbar-dark bg-primary">
      <a href="/" class="navbar-brand">Crud firebase</a>
    </nav>
    <div class="contaier">
      <div class="row mt-5">
        <div class="col-sm-4">
          <div class="card" id="cambiar">
            <div class="card-header">
              <h3>Añadir una nueva marca</h3>
            </div>
            <div class="card-body">
              <form @submit.prevent="addautos">
                <div class="form-group">
                  <input type="text" class="form-control" v-model="newautos.marca" placeholder="marca del auto">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" v-model="newautos.modelo" placeholder="modelo del auto">
                </div>
                
                <button type="submit" class="btn btn-primary">guardar</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-sm-8 text-center">
          <img src="./assets/logo.png" alt="vue">
          <div class="card">
            <div class="card-header">
              <h3>Autos</h3>
            </div>
            <div class="card-bdy">
              <table class="table">
                <thead>
                  <th>Marca</th>
                  <th>Modelo</th>
                </thead>
                <tbody>
                  <tr v-for="w in autos">
                    <td>
                      {{w.marca}}
                    </td>
                    <td>
                      {{w.modelo}}
                    </td>
                    <td>
                      <el-button @click="editautos(w, w.marca, w.modelo)" type="warning">Eddit</el-button>
                      <el-button @click="deleteautos(w)" type="danger">Delete</el-button>
                      
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import Firebase,{ functions } from 'firebase'
import 'firebase/app';
import 'firebase/firestore';
import config from './config'
let app = Firebase.initializeApp(config)
let db = app.database();
let autosref = db.ref('autos');
let contenedor = "";

export default {
  name: 'app',
  firebase: {
    autos: autosref
  },
  data(){
    return{
      newautos:{
        marca:'',
        modelo:''
      }
    }
  },
  methods:{
    addautos(){
      if(this.newautos.marca==''||this.newautos.modelo==''){
        this.$notify.error({
          title: 'Error',
          message: 'Estan Vacios los inputs'
        });
      }else{
        this.$notify.success({
          title: 'Info',
          message: 'Se Agrego Correctamente el auto',
          showClose: false
        });
        console.log(this.newautos.marca)
        autosref.push(this.newautos)
        this.newautos.marca = ''
        this.newautos.modelo = ''
      }
      
    },
    deleteautos(id){
       this.$confirm('Desea eliminar el auto permanentemente. Continue?', 'Warning', {
          confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }).then(() => {
          autosref.child(id['.key']).remove()
          this.$message({
            type: 'success',
            message: 'Delete completed'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: 'Delete canceled'
          });          
        });
    },
    editautos(id, marca, modelo ){
      const h = this.$createElement;
        this.$msgbox({
          title: 'Message',
          message: h('p', null, [
            h('span', null, 'Desea editar este auto: '),
            h('i', { style: 'color: teal' }, `${marca}`)
          ]),
          showCancelButton: true,
          confirmButtonText: 'Si',
          cancelButtonText: 'Cancel',
          beforeClose: (action, instance, done) => {
            if (action === 'confirm') {
              instance.confirmButtonLoading = true;
              instance.confirmButtonText = 'Loading...';
              setTimeout(() => {
                done();
                setTimeout(() => {
                  instance.confirmButtonLoading = false;
                }, 300);
              }, 3000);
            } else {
              done();
            }
          }
        }).then(action => {
          console.log(marca)
      this.newautos.marca = marca
      this.newautos.modelo = modelo
      autosref.child(id['.key']).remove()

       
          this.$message({
            type: 'success',
            message: 'Se agregaron los campos a editar: ' + action
          });
        });
      },
     
    }
  
}
</script>

<style>

</style>
