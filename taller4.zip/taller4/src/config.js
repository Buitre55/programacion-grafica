
export default {
    apiKey: "AIzaSyDM5YT1Cl71YE95pl32U252KHy_9rsVufc",
    authDomain: "pepe-8bbd4.firebaseapp.com",
    databaseURL: "https://pepe-8bbd4.firebaseio.com",
    projectId: "pepe-8bbd4",
    storageBucket: "pepe-8bbd4.appspot.com",
    messagingSenderId: "32313393811"
};
