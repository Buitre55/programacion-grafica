<template>


<div class="container">

<div class="alert alert-warning" role="alert">
 <p>Use de usuario: 'admin 'y contraseña:'admin'</p>
 </div>
<br/>
<div class="row align-items-center">
    <div class="col">
     
    </div>
    <div class="col">
<el-form ref="form" :model="form" label-width="150px">
  <el-form-item label="User">
    <el-input v-model="form.user"></el-input>
  </el-form-item>
<el-form-item label="Password" prop="pass">
    <el-input type="password" v-model="form.password" autocomplete="off"></el-input>
  </el-form-item>  
  <el-form-item>
    <el-button type="primary" @click="onSubmit">login</el-button>
    <el-button>Cancel</el-button>
  </el-form-item>
</el-form>

    </div>
    <div class="col">
      
    </div>
  </div>
</div>
       
</template>
<script>
export default {
  name: 'login',
  data () {
   return {
        form: {
          user: '',
          password: ''
        }
      }
    },
    methods: {
      onSubmit() {
          if(this.form.user==='admin'|| this.form.password==='admin'){
              console.log('buenisimo entrastes');
              location.href="#/form"
          }
       
      }
    }
  }
</script>
