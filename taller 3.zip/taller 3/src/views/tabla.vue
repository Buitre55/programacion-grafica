<template>
<div>
   <el-button  @click="cambiar" type="primary">Mostrar/ocultar</el-button>
  <el-card class="box-card"> <div v-if="mostrar">
  <div slot="header" class="clearfix">
    <span><strong>Usuario</strong> </span>
    
  </div>

  <div v-for="person in personas"class="text item">
    {{person}}
  </div>
  </div>
</el-card>

 
</div>
  </template>

  <script>
 
    export default {
      name: 'tabla',
      data() {
        
        return {
        mostrar: true,
        personas:JSON.parse(localStorage.getItem("persona"))
        }

        },
        methods: {
           cambiar: function() {
            this.mostrar = !this.mostrar;
        } 
         

      }
    }
  </script>