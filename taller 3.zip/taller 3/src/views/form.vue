<template>
<div>
<br/>


<div class="container">

<el-form ref="form" :model="person" label-width="120px" size="mini">
  <el-form-item label="Nombre">
    <el-input v-model="person.nombre"></el-input>
  </el-form-item>
 <el-form-item label="Apellido">
    <el-input v-model="person.apellido"></el-input>
  </el-form-item>


<el-form-item label="Fecha de nacimiento">
    <el-col :span="11">
      <el-date-picker type="date" placeholder="Selecciona la fecha" v-model="person.date" style="width: 100%;"></el-date-picker>
    </el-col>
  </el-form-item>

  <el-form-item label="Ciudad">
    <el-input v-model="person.ciudad"></el-input>
  </el-form-item>
  
  
  <el-form-item label="Ubicacion">
    <el-input v-model="person.Ubicacion"></el-input>
  </el-form-item>



   <el-form-item label="Estado">
    <el-select v-model="person.estado" placeholder="Estado de la persona">
      <el-option label="Activo" value="Activo"></el-option>
      <el-option label="Desactivado" value="Desactivado"></el-option>
    </el-select>
  </el-form-item>



  <el-form-item label="Direccion de entrega">
    <el-input type="textarea" v-model="person.direccionE"></el-input>
  </el-form-item>

  <el-form-item size="large">
    <el-button type="primary" @click="addperson()">Create</el-button>
    <el-button>Cancel</el-button>
  </el-form-item>
</el-form>
</div>
 </div>
</template>
<script>
  export default {
          name: 'form',
    data() {
    persona:''
      return {
    person: {
          nombre:'',
          apellido:'',
          date: '',
          ciudad: '',
          Ubicacion: '',
          estado: '',
          direccionE: ''
        }
      }
    },
    methods: {
      addperson() {
          this.persona={}
         localStorage.setItem("persona", JSON.stringify(this.person))
         this.persona= JSON.parse(localStorage.getItem("persona"))
           location.href="#/tabla"
        console.log(this.persona);
      }
    }
  }
</script>
<style scoped>

</style>